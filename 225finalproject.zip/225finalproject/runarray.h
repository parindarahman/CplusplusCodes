//Parinda Rahman-1931804042-section 2 cse 225
#ifndef RUNARRAY_H_INCLUDED
#define RUNARRAY_H_INCLUDED
#include<string.h>
#include <string>
using namespace std;
class runarray{
public:
    int findTotal();
    float findAverage();
    int findMax();
    int findMin();
    int id;
    string name;
    int runArray[10];


};

#endif // RUNARRAY_H_INCLUDED
